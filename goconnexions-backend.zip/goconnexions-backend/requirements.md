# Requirements

### python
### django
### djangorestframework
### mysqlclient
### pyJWT
### django-cors-headers
### sendgrid
### Pillow